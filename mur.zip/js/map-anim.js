jQuery(document).ready(function($) 
{

	var $segmentAnim1 = $('.fixed-map-wrapper svg #path-phoenix-nogales path');
	var $dotAnim1 = $('.fixed-map-wrapper svg #nogales-dot #step1-dot_2_ circle');
	//$mapAnim.hide();

	//tween = TweenMax.fromTo(".fixed-map-wrapper svg #sandiego-dot path", 1, {xPercent: 0, yPercent: 0}, {xPercent: -50, yPercent: -50, ease: Linear.easeNone}).fromTo(".fixed-map-wrapper svg #sandiego-text path", 1, {xPercent: 0, yPercent: 0}, {xPercent: -50, yPercent: -50, ease: Linear.easeNone});
	//tween2 = TweenMax.fromTo(".fixed-map-wrapper svg #sandiego-text path", 1, {xPercent: 0, yPercent: 0}, {xPercent: -50, yPercent: -50, ease: Linear.easeNone});
	//var $mapAnimLenght = $mapAnim.getTotalLength();

	var controllerMapAnim = new ScrollMagic.Controller();
	TweenMax.defaultOverwrite = false;
	TweenLite.defaultOverwrite = false;

	

	new ScrollMagic.Scene({
			triggerElement: 'h4', 
			triggerHook: 0.5
			//duration: (stepCitern * 10)
		})
		//.setPin('section.citern', {pushFollowers: true})
		.setClassToggle(".fixed-map-wrapper svg #path-phoenix-nogales path", "is-drawn")
		//.setTween(tween)
		//.setClassToggle(".fixed-map-wrapper svg #sandiego-dot path", "is-hidden")
		.offset( 0 ) //tip top
		.addIndicators() // add indicators (requires plugin)
		.addTo(controllerMapAnim);

	new ScrollMagic.Scene({
			triggerElement: 'h4', 
			triggerHook: 0.5
			//duration: (stepCitern * 10)
		})
		//.setPin('section.citern', {pushFollowers: true})
		.setTween($dotAnim1, 0.5, {scale: 1.3, transformOrigin:'50% 50%', delay: 1.3,  ease: Bounce.easeOut}) 
		//.setTween(tween)
		//.setClassToggle(".fixed-map-wrapper svg #sandiego-dot path", "is-hidden")
		.offset( 0 ) //tip top
		.addIndicators() // add indicators (requires plugin)
		.addTo(controllerMapAnim);




	// $('p').on('click', function(event) {

	// 	$mapAnim.show();

	// });

	// $('h3').on('click', function(event) {

	// 	$mapAnim2.show();

	// });

});