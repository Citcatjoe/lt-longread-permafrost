jQuery(document).ready(function($) 
{

	// var $hand = $('svg.hand'),
	// 	$doigt = $('#doigt'),
	// 	$ligne = $('#ligne'),
	// 	tlClic;

	// tlClic = new TimelineMax({ paused: true });

	// tlClic
	// 	.set([$ligne], {autoAlpha: 0})
	// 	.to([$hand], 2, {autoAlpha: 1, xPercent: '-250', ease: Power4.easeOut})
	// 	.to([$ligne], 0.2, {autoAlpha: 1})
	// 	.to([$ligne], 0.2, {autoAlpha: 0})
	// 	.to([$ligne], 0.2, {autoAlpha: 1})
	// 	.to([$ligne], 0.2, {autoAlpha: 0})
	// 	.to([$ligne], 0.2, {autoAlpha: 1})
	// 	.to([$ligne], 0.2, {autoAlpha: 0})
	// 	.to([$hand], 2, {autoAlpha: 0, xPercent: '0', ease: Power4.easeOut});

	// var ctrlClic = new ScrollMagic.Controller({
	// 	globalSceneOptions: {
	// 		triggerHook: 'onEnter',
	// 		triggerElement: "section.chrono"
	// 	}
	// });

	// //var $chronoH = $('section.chrono').height();
	// //alert($chronoH);
	// new ScrollMagic.Scene({
	//   offset: 400
	// })
	// //.setClassToggle("video", "is-active")
	// //.addIndicators({name: "Clic Clic"}) // add indicators (requires plugin)
	// .addTo(ctrlClic)
	// .on("enter", function (e) {
	// 	tlClic.play();	
	// });

});