Si besoin d'un header spécifique ou si le dossier n'est pas à la bonne hauteur de l'arborescence (_sandbox par exemple),
une copie du fichier _blocks.html-twig peut être placée dans ce répertoire.

Dès lors, ce fichier sera utilisé à la place du header global et pourra être spécifique au dossier.