jQuery(document).ready(function($) 
{

	var windowW = $(window).width();
	if((windowW > 1200))
	{
		// PIN EFFECT on SECTION.GALLERY.HERO
		// init controller
		var ctrlHeroImg = new ScrollMagic.Controller({
	        globalSceneOptions: {
	            triggerHook: 'onLeave',
	        }
	    });
	    // build scene
		$(".hero").each(function() {
		 
		   new ScrollMagic.Scene({
		       triggerElement: this,
		       duration: 800
		   })
		   .setPin(this, {pushFollowers: true})
		   //.addIndicators()
		   .addTo(ctrlHeroImg);
		});
	}

});